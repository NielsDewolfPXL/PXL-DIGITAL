package be.pxl.vraag1;

public class OptredenOverlapException extends Exception {
	public OptredenOverlapException(String message) {
		super(message);
	}
}
