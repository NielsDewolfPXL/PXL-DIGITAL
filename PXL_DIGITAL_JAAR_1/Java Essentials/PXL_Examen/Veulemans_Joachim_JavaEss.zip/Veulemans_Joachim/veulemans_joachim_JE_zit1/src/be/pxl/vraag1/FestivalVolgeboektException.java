package be.pxl.vraag1;

public class FestivalVolgeboektException extends Exception {
	public FestivalVolgeboektException(String message) {
		super(message);
	}
}
