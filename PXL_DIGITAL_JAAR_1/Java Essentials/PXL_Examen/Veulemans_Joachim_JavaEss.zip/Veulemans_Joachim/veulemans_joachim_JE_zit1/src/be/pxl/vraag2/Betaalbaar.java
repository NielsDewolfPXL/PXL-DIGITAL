package be.pxl.vraag2;

public interface Betaalbaar {
	double berekenPrijs();
}
