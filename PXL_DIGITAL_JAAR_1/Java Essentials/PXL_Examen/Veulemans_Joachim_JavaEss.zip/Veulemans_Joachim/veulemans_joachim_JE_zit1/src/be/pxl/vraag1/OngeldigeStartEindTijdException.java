package be.pxl.vraag1;

public class OngeldigeStartEindTijdException extends Exception {
	public OngeldigeStartEindTijdException(String message) {
		super(message);
	}
}
