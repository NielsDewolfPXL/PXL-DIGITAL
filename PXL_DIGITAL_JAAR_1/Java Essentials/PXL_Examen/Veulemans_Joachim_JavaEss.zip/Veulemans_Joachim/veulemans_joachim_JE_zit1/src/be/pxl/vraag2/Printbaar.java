package be.pxl.vraag2;

public interface Printbaar {
	void print();
	void print(int aantal, char teken);
}
