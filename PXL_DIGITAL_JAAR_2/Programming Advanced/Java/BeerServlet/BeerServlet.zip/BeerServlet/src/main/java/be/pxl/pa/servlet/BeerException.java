package be.pxl.pa.servlet;

public class BeerException extends Exception {
    public BeerException (Exception message) {
        super (message);
    }
}
