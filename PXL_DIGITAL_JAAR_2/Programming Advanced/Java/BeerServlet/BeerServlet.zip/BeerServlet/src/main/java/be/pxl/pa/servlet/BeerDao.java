package be.pxl.pa.servlet;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BeerDao {

    private String url;
    private String user;
    private String password;

    public BeerDao() {

    }

    public BeerDao(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    public List<Beer> getAllBeers(Connection connection) throws BeerException, SQLException {
        List<Beer> beerList = new ArrayList<>();
        PreparedStatement stmt = connection.prepareStatement("Select * FROM Beers");
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Beer beer = new Beer();
            beer.setName(rs.getString("Name"));
            beer.setId(rs.getInt("id"));
            beer.setAlcohol(rs.getFloat("Alcohol"));
            beer.setPrice(rs.getFloat("Price"));
            beer.setStock(rs.getInt("Stock"));
            beerList.add(beer);
        }
        return beerList;
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
}

