package be.pxl.pa.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name="BeerServlet")
public class BeerServlet extends HttpServlet {
    private String url;
    private String user;
    private String password;
    private BeerDao beerDao;
    private Connection connection;
    private List<Beer> beerList;

    @Override
    public void init() {
        url = getInitParameter("url");
        user = getInitParameter("user");
        password = getInitParameter("password");
        try {
            beerList = new ArrayList<>();
            Class.forName("com.mysql.jdbc.Driver");
            beerDao = new BeerDao(url, user, password);
            Connection connection = beerDao.getConnection();
            beerList = beerDao.getAllBeers(connection);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } catch (BeerException ex) {
            System.out.println(ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<html><head><title>BeerServlet</title></head>");
            out.println("<body>");
            out.println("<h1> All Beers </h1");
            for (Beer beer : beerList) {
                out.println("<p> Beer name: " + beer.getName() + "<p>");
            }
        }
    }
}
