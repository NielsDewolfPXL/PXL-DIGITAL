package be.pxl.pa.servlet;

import java.io.Serializable;

public class Beer implements Serializable {

    private String name;
    private Float price;
    private int stock;
    private float alcohol;

    public Beer(){

    }

    public Beer(String name, Float price, int stock, float alcohol) {
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.alcohol = alcohol;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Float getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public float getAlcohol() {
        return alcohol;
    }

    private int id;

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setAlcohol(float alcohol) {
        this.alcohol = alcohol;
    }

    @Override
    public String toString() {
        return "Beer{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                ", alcohol=" + alcohol +
                ", id=" + id +
                '}';
    }
}
